<?
//
// File:    hello.php
// Purpose: prints Hello World.
// Author:  pc2@ecs.csus.edu at http://www.ecs.csus.edu/pc2
//
// $Id$
//
print "Hello World.";
?>
